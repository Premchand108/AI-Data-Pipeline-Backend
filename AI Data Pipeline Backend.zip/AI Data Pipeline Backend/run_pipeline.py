#!/usr/bin/env python
"""
Standalone CLI Runner for AI Data Pipeline Backend.
Allows running the nightly pipeline synchronously or dispatching via Celery,
generating mock sales feeds, and printing live pipeline observability metrics.
"""

import os
import sys
import uuid
import argparse
import logging
from datetime import datetime

# Setup paths and logging
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.connection import init_db, SessionFactory
from pipeline.orchestrator import PipelineOrchestrator
from pipeline.collectors.mock_data_generator import generate_and_save_mock_csv
from config.settings import settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger("PipelineRunner")

def main():
    parser = argparse.ArgumentParser(description="AI Data Pipeline CLI Runner")
    parser.add_argument(
        "--mode",
        choices=["direct", "celery"],
        default="direct",
        help="Run mode: 'direct' runs immediately in-process; 'celery' queues as Celery task"
    )
    parser.add_argument(
        "--file",
        type=str,
        default=None,
        help="Path to CSV sales file to ingest. If omitted, mock sales data will be generated."
    )
    parser.add_argument(
        "--days",
        type=int,
        default=60,
        help="Number of days of synthetic data to generate if no file is provided (default: 60)"
    )
    parser.add_argument(
        "--batch-id",
        type=str,
        default=None,
        help="Custom batch ID (default: auto-generated timestamped ID)"
    )
    parser.add_argument(
        "--no-retrain",
        action="store_true",
        help="Skip retraining the AI model and use current active model"
    )

    args = parser.parse_args()

    # 1. Initialize DB tables
    logger.info("Initializing database tables...")
    init_db()

    # 2. Determine batch ID
    batch_id = args.batch_id or f"BATCH_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    
    # 3. Prepare Input CSV File
    csv_file = args.file
    if not csv_file or not os.path.exists(csv_file):
        sample_path = os.path.join(settings.DATA_DIR, f"sales_input_{batch_id}.csv")
        logger.info(f"Generating synthetic {args.days}-day sales dataset at {sample_path} (with anomaly injection)...")
        generate_and_save_mock_csv(sample_path, num_days=args.days, inject_anomalies=True)
        csv_file = sample_path

    logger.info(f"Starting pipeline execution for batch: {batch_id}")
    logger.info(f"Target data file: {csv_file}")
    logger.info(f"Execution mode: {args.mode}")

    if args.mode == "direct":
        # Synchronous execution
        db = SessionFactory()
        orchestrator = PipelineOrchestrator(db=db)
        try:
            result = orchestrator.run_nightly_pipeline(
                batch_id=batch_id,
                csv_file_path=csv_file,
                retrain_model=not args.no_retrain
            )
            print("\n" + "=" * 60)
            print("PIPELINE EXECUTION SUMMARY")
            print("=" * 60)
            print(f"Status:             {result.get('status')}")
            print(f"Batch ID:           {result.get('batch_id')}")
            print(f"Duration:           {result.get('duration_seconds')} seconds")
            
            metrics = result.get("metrics", {})
            val_stats = metrics.get("validation_stats", {})
            print(f"Total Inspected:    {val_stats.get('total_inspected', 0)}")
            print(f"Valid Records:      {val_stats.get('valid_count', 0)}")
            print(f"Quarantined Records:{val_stats.get('quarantined_count', 0)}")
            
            model_metrics = metrics.get("model_metrics", {})
            if model_metrics:
                print(f"AI Model Version:   {metrics.get('trained_model_version')}")
                print(f"Model Eval MAE:     {model_metrics.get('eval_mae')}")
                print(f"Model Eval RMSE:    {model_metrics.get('eval_rmse')}")
                print(f"Model Eval R²:      {model_metrics.get('eval_r2')}")
            
            print(f"Forecasts Created:  {metrics.get('forecast_count', 0)}")
            print("=" * 60)

            sample_preds = result.get("sample_predictions", [])
            if sample_preds:
                print("\nSample 7-Day AI Sales Forecasts:")
                print(f"{'Store':<12} | {'Product':<15} | {'Date':<11} | {'Forecast Qty':<12} | {'Revenue ($)':<11} | {'Confidence Interval'}")
                print("-" * 85)
                for p in sample_preds[:8]:
                    ci = f"[{p['confidence_lower']} - {p['confidence_upper']}]"
                    print(f"{p['store_id']:<12} | {p['product_id']:<15} | {p['forecast_date']:<11} | {p['predicted_quantity']:<12.1f} | ${p['predicted_revenue']:<10.2f} | {ci}")
            print("=" * 60 + "\n")
            return 0 if result.get("status") == "SUCCESS" else 1
        finally:
            orchestrator.close()

    elif args.mode == "celery":
        # Asynchronous dispatch via Celery
        try:
            from celery_app.tasks import task_run_nightly_pipeline
            task = task_run_nightly_pipeline.delay(
                batch_id=batch_id,
                csv_file_path=csv_file,
                generate_sample_if_missing=False
            )
            print("\n" + "=" * 60)
            print("CELERY TASK DISPATCHED")
            print("=" * 60)
            print(f"Task ID:    {task.id}")
            print(f"Batch ID:   {batch_id}")
            print(f"Status:     {task.status}")
            print(f"Log Info:   Monitoring Celery queue. Worker will process asynchronously.")
            print("=" * 60 + "\n")
            return 0
        except Exception as e:
            logger.error(f"Failed to dispatch Celery task: {e}")
            logger.info("Ensure Redis is running or test in direct mode: python run_pipeline.py --mode direct")
            return 1

if __name__ == "__main__":
    sys.exit(main())
