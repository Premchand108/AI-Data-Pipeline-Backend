import os
import joblib
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, List
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sqlalchemy.orm import Session

from config.settings import settings
from database.models import (
    AIFeatureStore,
    AIForecastPrediction,
    ModelMetadata,
    PipelineRun,
    CleanSalesRecord
)

logger = logging.getLogger(__name__)

FEATURE_COLUMNS = [
    "day_of_week",
    "day_of_month",
    "month",
    "is_weekend",
    "is_promotion_active",
    "lag_1_qty",
    "lag_7_qty",
    "lag_14_qty",
    "rolling_7_mean_qty",
    "rolling_7_std_qty",
    "rolling_14_mean_qty",
    "rolling_30_mean_qty",
]

class AISalesForecaster:
    """
    AI Forecasting Engine: Trains and updates machine learning forecasting models
    on historical features from the Gold store, evaluates validation metrics,
    persists model artifacts with lineage tracking, and generates multi-day forecasts.
    """
    def __init__(self, db_session: Session):
        self.db = db_session

    def train_and_evaluate(self, batch_id: str = None) -> Tuple[str, Dict[str, float]]:
        """
        Pulls features from Gold store, trains a RandomForest regressor,
        computes evaluation metrics, persists model artifact, and registers metadata.
        """
        logger.info("Loading feature store dataset for model training...")
        
        # Load feature store data
        features = self.db.query(AIFeatureStore).order_by(AIFeatureStore.feature_date.asc()).all()
        if not features or len(features) < 15:
            raise ValueError(f"Insufficient feature data to train AI model ({len(features)} rows).")

        data = []
        for f in features:
            data.append({
                "store_id": f.store_id,
                "product_id": f.product_id,
                "feature_date": f.feature_date,
                "sales_quantity": f.sales_quantity,
                "sales_revenue": f.sales_revenue,
                "lag_1_qty": f.lag_1_qty,
                "lag_7_qty": f.lag_7_qty,
                "lag_14_qty": f.lag_14_qty,
                "rolling_7_mean_qty": f.rolling_7_mean_qty,
                "rolling_7_std_qty": f.rolling_7_std_qty,
                "rolling_14_mean_qty": f.rolling_14_mean_qty,
                "rolling_30_mean_qty": f.rolling_30_mean_qty,
                "day_of_week": f.day_of_week,
                "day_of_month": f.day_of_month,
                "month": f.month,
                "is_weekend": int(f.is_weekend),
                "is_promotion_active": int(f.is_promotion_active)
            })

        df = pd.DataFrame(data)

        # One-hot encode store_id and product_id
        df_encoded = pd.get_dummies(df, columns=["store_id", "product_id"], drop_first=False)
        encoded_cols = [c for c in df_encoded.columns if c.startswith("store_id_") or c.startswith("product_id_")]
        
        feature_set = FEATURE_COLUMNS + encoded_cols
        X = df_encoded[feature_set].fillna(0.0)
        y = df_encoded["sales_quantity"]

        # Time-based train-test split (80% train, 20% validation)
        split_idx = int(len(df_encoded) * 0.8)
        X_train, X_val = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_val = y.iloc[:split_idx], y.iloc[split_idx:]

        logger.info(f"Training RandomForest with {len(X_train)} samples, evaluating on {len(X_val)} samples")
        
        model = RandomForestRegressor(
            n_estimators=100,
            max_depth=12,
            min_samples_split=4,
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_train, y_train)

        # Evaluate metrics
        y_pred = model.predict(X_val)
        y_pred = np.maximum(y_pred, 0.0)  # Quantity cannot be negative

        mae = float(mean_absolute_error(y_val, y_pred))
        rmse = float(np.sqrt(mean_squared_error(y_val, y_pred)))
        r2 = float(r2_score(y_val, y_pred))
        
        # MAPE with small epsilon to prevent division by zero
        non_zero = y_val > 0
        if non_zero.sum() > 0:
            mape = float(np.mean(np.abs((y_val[non_zero] - y_pred[non_zero]) / y_val[non_zero])) * 100)
        else:
            mape = 0.0

        metrics = {
            "eval_mae": round(mae, 4),
            "eval_rmse": round(rmse, 4),
            "eval_r2": round(r2, 4),
            "eval_mape": round(mape, 2),
            "train_samples": len(X_train),
            "val_samples": len(X_val)
        }

        # Model Versioning & Artifact Persistence
        version = f"v_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
        artifact_filename = f"model_sales_rf_{version}.joblib"
        artifact_path = os.path.join(settings.MODEL_STORE_DIR, artifact_filename)

        bundle = {
            "version": version,
            "model": model,
            "feature_set": feature_set,
            "metrics": metrics,
            "created_at": datetime.utcnow().isoformat()
        }
        joblib.dump(bundle, artifact_path)

        # Deactivate older models in DB registry and activate this one
        self.db.query(ModelMetadata).update({ModelMetadata.is_active: False})
        
        meta = ModelMetadata(
            version=version,
            model_type="RandomForest_TimeSeries",
            training_date=datetime.utcnow(),
            train_samples=len(X_train),
            eval_mae=mae,
            eval_rmse=rmse,
            eval_r2=r2,
            eval_mape=mape,
            artifact_path=artifact_path,
            hyperparameters={"n_estimators": 100, "max_depth": 12, "random_state": 42},
            is_active=True
        )
        self.db.add(meta)
        self.db.commit()

        # Update PipelineRun status
        if batch_id:
            run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
            if run_record:
                run_record.current_stage = "MODEL_TRAINING_COMPLETED"
                summary = run_record.metrics_summary or {}
                summary["model_training"] = {
                    "version": version,
                    "metrics": metrics,
                    "artifact": artifact_path
                }
                run_record.metrics_summary = summary
                self.db.commit()

        logger.info(f"Model {version} successfully trained! MAE: {mae:.2f}, RMSE: {rmse:.2f}, R2: {r2:.2f}")
        return version, metrics

    def generate_forecasts(
        self,
        batch_id: str,
        horizon_days: int = 7
    ) -> Tuple[int, List[Dict[str, Any]]]:
        """
        Uses the latest active model to generate forward predictions for each
        store & product combination across the forecast horizon.
        """
        active_meta = self.db.query(ModelMetadata).filter(ModelMetadata.is_active == True).first()
        if not active_meta or not os.path.exists(active_meta.artifact_path):
            raise FileNotFoundError("Active model artifact not found. Please train a model first.")

        bundle = joblib.load(active_meta.artifact_path)
        model = bundle["model"]
        feature_set = bundle["feature_set"]

        # Fetch recent features to seed forecast lags
        latest_features = self.db.query(AIFeatureStore).order_by(AIFeatureStore.feature_date.desc()).all()
        if not latest_features:
            raise ValueError("No features available in Gold store to generate forecasts.")

        # Distinct store and product pairs
        store_prods = self.db.query(
            CleanSalesRecord.store_id,
            CleanSalesRecord.product_id,
            CleanSalesRecord.unit_price
        ).group_by(CleanSalesRecord.store_id, CleanSalesRecord.product_id).all()

        price_lookup = {(sp.store_id, sp.product_id): sp.unit_price for sp in store_prods}

        max_date = max(f.feature_date for f in latest_features)
        forecast_predictions = []

        # Remove prior forecasts for this batch or future overlap
        self.db.query(AIForecastPrediction).filter(
            AIForecastPrediction.forecast_date > max_date
        ).delete()
        self.db.commit()

        for sp in store_prods:
            store_id = sp.store_id
            product_id = sp.product_id
            unit_price = price_lookup.get((store_id, product_id), 25.0)

            # Get latest known features for this series
            recent = [f for f in latest_features if f.store_id == store_id and f.product_id == product_id]
            if not recent:
                continue

            latest_known = recent[0]  # most recent date
            running_qty = latest_known.sales_quantity
            running_mean = latest_known.rolling_7_mean_qty or running_qty
            running_std = latest_known.rolling_7_std_qty or 1.0

            for h in range(1, horizon_days + 1):
                f_date = max_date + timedelta(days=h)
                dow = f_date.weekday()
                is_weekend = dow in (5, 6)

                # Prepare single-row feature vector
                row_dict = {
                    "day_of_week": dow,
                    "day_of_month": f_date.day,
                    "month": f_date.month,
                    "is_weekend": int(is_weekend),
                    "is_promotion_active": 0,
                    "lag_1_qty": running_qty,
                    "lag_7_qty": running_mean,
                    "lag_14_qty": running_mean,
                    "rolling_7_mean_qty": running_mean,
                    "rolling_7_std_qty": running_std,
                    "rolling_14_mean_qty": running_mean,
                    "rolling_30_mean_qty": running_mean,
                }

                # Encode categorical dummies
                for c in feature_set:
                    if c.startswith("store_id_"):
                        row_dict[c] = 1 if c == f"store_id_{store_id}" else 0
                    elif c.startswith("product_id_"):
                        row_dict[c] = 1 if c == f"product_id_{product_id}" else 0

                row_df = pd.DataFrame([row_dict]).reindex(columns=feature_set, fill_value=0.0)
                pred_qty = float(np.maximum(0.0, model.predict(row_df)[0]))
                
                # Confidence intervals (95% approx using rolling standard deviation)
                std_margin = 1.96 * max(1.0, running_std)
                conf_lower = max(0.0, round(pred_qty - std_margin, 2))
                conf_upper = round(pred_qty + std_margin, 2)
                pred_revenue = round(pred_qty * unit_price, 2)

                pred_obj = AIForecastPrediction(
                    batch_id=batch_id,
                    model_version=active_meta.version,
                    store_id=store_id,
                    product_id=product_id,
                    forecast_date=f_date,
                    predicted_quantity=round(pred_qty, 2),
                    predicted_revenue=pred_revenue,
                    confidence_lower=conf_lower,
                    confidence_upper=conf_upper,
                    generated_at=datetime.utcnow()
                )
                forecast_predictions.append(pred_obj)

                # Update running state for next step
                running_qty = pred_qty

        # Bulk save predictions
        if forecast_predictions:
            self.db.bulk_save_objects(forecast_predictions)
            self.db.commit()

        # Update PipelineRun
        run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
        if run_record:
            run_record.current_stage = "FORECASTING_COMPLETED"
            summary = run_record.metrics_summary or {}
            summary["forecasting"] = {
                "model_version": active_meta.version,
                "horizon_days": horizon_days,
                "predictions_generated": len(forecast_predictions)
            }
            run_record.metrics_summary = summary
            self.db.commit()

        logger.info(f"Generated {len(forecast_predictions)} forecast predictions across {horizon_days} days.")
        return len(forecast_predictions), [
            {
                "store_id": p.store_id,
                "product_id": p.product_id,
                "forecast_date": p.forecast_date.strftime("%Y-%m-%d"),
                "predicted_quantity": p.predicted_quantity,
                "predicted_revenue": p.predicted_revenue,
                "confidence_lower": p.confidence_lower,
                "confidence_upper": p.confidence_upper
            }
            for p in forecast_predictions[:20]
        ]
