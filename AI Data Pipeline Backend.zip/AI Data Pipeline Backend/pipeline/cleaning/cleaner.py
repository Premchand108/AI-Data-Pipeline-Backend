import logging
from datetime import datetime
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np
from sqlalchemy.orm import Session
from database.models import CleanSalesRecord, PipelineRun

logger = logging.getLogger(__name__)

class DataCleaner:
    """
    Silver Layer Processing: Cleans, transforms, deduplicates,
    and enriches validated sales data, then stores it in clean_sales_records.
    """
    def __init__(self, db_session: Session):
        self.db = db_session

    def clean_and_store(self, valid_df: pd.DataFrame, batch_id: str) -> Tuple[int, Dict[str, Any]]:
        """
        Takes validated DataFrame, cleans it, deduplicates it, calculates derived
        fields, and bulk-inserts into clean_sales_records.
        """
        if valid_df.empty:
            logger.warning(f"Batch {batch_id} has 0 valid records to clean.")
            return 0, {"cleaned_records": 0, "deduplicated_count": 0}

        logger.info(f"Starting cleaning pipeline for {len(valid_df)} valid records in batch {batch_id}")
        df = valid_df.copy()

        initial_count = len(df)

        # 1. Deduplication on transaction_id
        df.drop_duplicates(subset=["transaction_id"], keep="last", inplace=True)
        dedup_dropped = initial_count - len(df)

        # 2. Standardize Strings (trim whitespace, normalize casing)
        df["store_id"] = df["store_id"].astype(str).str.strip().str.upper()
        df["product_id"] = df["product_id"].astype(str).str.strip().str.upper()
        df["category"] = df["category"].fillna("General").astype(str).str.strip().str.title()

        # 3. Standardize Datetime
        df["sale_date"] = pd.to_datetime(df["sale_date"])

        # 4. Enforce Numeric Types
        df["quantity"] = df["quantity"].astype(int)
        df["unit_price"] = df["unit_price"].astype(float).round(2)
        df["discount_rate"] = df["discount_rate"].fillna(0.0).astype(float).round(4)
        df["is_promotion"] = df["is_promotion"].fillna(False).astype(bool)

        # 5. Outlier Detection and Capping on Quantity (IQR method)
        q25 = df["quantity"].quantile(0.25)
        q75 = df["quantity"].quantile(0.75)
        iqr = q75 - q25
        upper_bound = q75 + 4.0 * iqr
        outlier_mask = df["quantity"] > upper_bound
        outliers_capped = int(outlier_mask.sum())
        if outliers_capped > 0:
            df.loc[outlier_mask, "quantity"] = int(np.floor(upper_bound))

        # 6. Calculate Derived Metric: total_amount
        df["total_amount"] = (
            df["quantity"] * df["unit_price"] * (1.0 - df["discount_rate"])
        ).round(2)

        # 7. Persist to Silver Layer (CleanSalesRecord)
        clean_objects = []
        for _, row in df.iterrows():
            clean_rec = CleanSalesRecord(
                batch_id=batch_id,
                transaction_id=str(row["transaction_id"]),
                store_id=str(row["store_id"]),
                product_id=str(row["product_id"]),
                category=str(row["category"]),
                sale_date=row["sale_date"].to_pydatetime(),
                quantity=int(row["quantity"]),
                unit_price=float(row["unit_price"]),
                discount_rate=float(row["discount_rate"]),
                total_amount=float(row["total_amount"]),
                is_promotion=bool(row["is_promotion"]),
                cleaned_at=datetime.utcnow()
            )
            clean_objects.append(clean_rec)

            if len(clean_objects) >= 1000:
                self.db.bulk_save_objects(clean_objects)
                self.db.commit()
                clean_objects = []

        if clean_objects:
            self.db.bulk_save_objects(clean_objects)
            self.db.commit()

        # Update PipelineRun
        run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
        if run_record:
            run_record.current_stage = "CLEANING_COMPLETED"
            summary = run_record.metrics_summary or {}
            summary["cleaning"] = {
                "initial_valid_rows": initial_count,
                "cleaned_stored": len(df),
                "deduplicated_dropped": dedup_dropped,
                "outliers_capped": outliers_capped,
                "total_sales_volume": float(df["quantity"].sum()),
                "total_sales_revenue": float(df["total_amount"].sum())
            }
            run_record.metrics_summary = summary
            self.db.commit()

        cleaning_stats = {
            "initial_valid_rows": initial_count,
            "cleaned_stored": len(df),
            "deduplicated_dropped": dedup_dropped,
            "outliers_capped": outliers_capped,
            "total_sales_volume": float(df["quantity"].sum()),
            "total_sales_revenue": float(df["total_amount"].sum())
        }

        logger.info(f"Silver cleaning completed for batch {batch_id}: {len(df)} records stored.")
        return len(df), cleaning_stats
