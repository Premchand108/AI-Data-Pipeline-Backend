import time
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from database.connection import SessionFactory
from database.models import PipelineRun
from pipeline.collectors.csv_collector import CSVDataCollector
from pipeline.validation.validator import DataQualityValidator
from pipeline.cleaning.cleaner import DataCleaner
from pipeline.features.engineering import FeatureEngineer
from pipeline.models.forecaster import AISalesForecaster

logger = logging.getLogger(__name__)

class PipelineOrchestrator:
    """
    Master Orchestration Engine:
    Executes the end-to-end data pipeline:
    Data Collection -> Validation Gate -> Cleaning & Enrichment ->
    Feature Store Population -> AI Model Retraining -> Forecasting & Observability Audit.
    """
    def __init__(self, db: Optional[Session] = None):
        self.db = db or SessionFactory()
        self._owns_session = db is None

    def close(self):
        if self._owns_session and self.db:
            self.db.close()

    def run_nightly_pipeline(
        self,
        batch_id: str,
        csv_file_path: Optional[str] = None,
        retrain_model: bool = True
    ) -> Dict[str, Any]:
        """
        Executes the entire automated nightly sales forecasting pipeline.
        Provides stage-by-stage observability, latency tracking, and robust error handling.
        """
        start_time = time.time()
        logger.info(f"=== [START] NIGHTLY PIPELINE EXECUTION FOR BATCH {batch_id} ===")

        # Ensure run tracker exists
        run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
        if not run_record:
            run_record = PipelineRun(
                batch_id=batch_id,
                pipeline_name="nightly_sales_forecast_pipeline",
                status="RUNNING",
                current_stage="INITIALIZING",
                start_time=datetime.utcnow()
            )
            self.db.add(run_record)
            self.db.commit()
        else:
            run_record.status = "RUNNING"
            run_record.start_time = datetime.utcnow()
            self.db.commit()

        metrics_summary = run_record.metrics_summary or {}

        try:
            # 1. INGESTION STAGE (Bronze Layer)
            stage_start = time.time()
            collector = CSVDataCollector(self.db)
            if csv_file_path:
                total_raw, _ = collector.ingest_file(csv_file_path, batch_id=batch_id)
            else:
                total_raw = run_record.total_raw_rows
            metrics_summary["ingestion_duration_sec"] = round(time.time() - stage_start, 3)

            # 2. VALIDATION STAGE (Data Quality Gate / Quarantine)
            stage_start = time.time()
            validator = DataQualityValidator(self.db)
            valid_df, quarantined_count, val_stats = validator.validate_batch(batch_id=batch_id)
            metrics_summary["validation_duration_sec"] = round(time.time() - stage_start, 3)
            metrics_summary["validation_stats"] = val_stats

            # 3. CLEANING STAGE (Silver Layer)
            stage_start = time.time()
            cleaner = DataCleaner(self.db)
            cleaned_count, clean_stats = cleaner.clean_and_store(valid_df=valid_df, batch_id=batch_id)
            metrics_summary["cleaning_duration_sec"] = round(time.time() - stage_start, 3)
            metrics_summary["cleaning_stats"] = clean_stats

            # 4. FEATURE ENGINEERING STAGE (Gold Layer Feature Store)
            stage_start = time.time()
            fe = FeatureEngineer(self.db)
            feature_count, fe_stats = fe.build_and_store_features(batch_id=batch_id)
            metrics_summary["feature_eng_duration_sec"] = round(time.time() - stage_start, 3)
            metrics_summary["feature_stats"] = fe_stats

            # 5. AI MODEL RETRAINING & INFERENCE STAGE
            forecaster = AISalesForecaster(self.db)
            if retrain_model:
                stage_start = time.time()
                version, model_metrics = forecaster.train_and_evaluate(batch_id=batch_id)
                metrics_summary["training_duration_sec"] = round(time.time() - stage_start, 3)
                metrics_summary["trained_model_version"] = version
                metrics_summary["model_metrics"] = model_metrics

            stage_start = time.time()
            forecast_count, sample_preds = forecaster.generate_forecasts(batch_id=batch_id, horizon_days=7)
            metrics_summary["forecasting_duration_sec"] = round(time.time() - stage_start, 3)
            metrics_summary["forecast_count"] = forecast_count

            # FINAL AUDIT UPDATE: SUCCESS
            total_duration = time.time() - start_time
            run_record.status = "SUCCESS"
            run_record.current_stage = "COMPLETED"
            run_record.end_time = datetime.utcnow()
            run_record.duration_seconds = round(total_duration, 2)
            run_record.metrics_summary = metrics_summary
            self.db.commit()

            logger.info(f"=== [SUCCESS] NIGHTLY PIPELINE COMPLETED IN {total_duration:.2f}s ===")
            return {
                "status": "SUCCESS",
                "batch_id": batch_id,
                "duration_seconds": round(total_duration, 2),
                "metrics": metrics_summary,
                "sample_predictions": sample_preds
            }

        except Exception as e:
            self.db.rollback()
            total_duration = time.time() - start_time
            logger.error(f"Pipeline execution failed for batch {batch_id}: {str(e)}", exc_info=True)
            
            run_record.status = "FAILED"
            run_record.current_stage = "ERROR"
            run_record.end_time = datetime.utcnow()
            run_record.duration_seconds = round(total_duration, 2)
            run_record.error_message = str(e)
            run_record.metrics_summary = metrics_summary
            self.db.commit()

            return {
                "status": "FAILED",
                "batch_id": batch_id,
                "duration_seconds": round(total_duration, 2),
                "error": str(e)
            }
        finally:
            if self._owns_session:
                self.close()
