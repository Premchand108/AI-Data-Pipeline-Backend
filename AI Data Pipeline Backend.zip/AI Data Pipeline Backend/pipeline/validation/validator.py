import json
import logging
from datetime import datetime
from typing import Tuple, List, Dict, Any
import pandas as pd
from sqlalchemy.orm import Session
from database.models import RawSalesIngestion, QuarantinedRecord, PipelineRun

logger = logging.getLogger(__name__)

class DataQualityValidator:
    """
    Data Quality Gate: Validates incoming raw sales transactions against
    business and schema rules. Invalid records are isolated into the Quarantine
    layer with explicit error diagnostics, ensuring clean data downstream.
    """
    REQUIRED_COLUMNS = ["transaction_id", "store_id", "product_id", "sale_date", "quantity", "unit_price"]

    def __init__(self, db_session: Session):
        self.db = db_session

    def validate_batch(self, batch_id: str) -> Tuple[pd.DataFrame, int, Dict[str, Any]]:
        """
        Loads raw records for batch_id from Bronze table, runs validation rules,
        stores quarantined records in database, and returns valid records as a DataFrame.
        """
        logger.info(f"Running data quality validation for batch {batch_id}")
        raw_entries = self.db.query(RawSalesIngestion).filter(
            RawSalesIngestion.batch_id == batch_id
        ).all()

        if not raw_entries:
            raise ValueError(f"No raw ingestion records found for batch {batch_id}")

        valid_rows = []
        quarantine_objects = []
        error_counters: Dict[str, int] = {}

        for entry in raw_entries:
            raw_dict = json.loads(entry.raw_payload)
            errors = self._validate_record(raw_dict)

            if not errors:
                valid_rows.append(raw_dict)
            else:
                for error_code, error_msg, field_name in errors:
                    error_counters[error_code] = error_counters.get(error_code, 0) + 1
                    q_record = QuarantinedRecord(
                        batch_id=batch_id,
                        raw_record_id=entry.id,
                        field_name=field_name,
                        error_code=error_code,
                        error_message=error_msg,
                        invalid_payload=entry.raw_payload,
                        quarantined_at=datetime.utcnow()
                    )
                    quarantine_objects.append(q_record)

        # Bulk save quarantined records to database
        if quarantine_objects:
            self.db.bulk_save_objects(quarantine_objects)
            self.db.commit()

        valid_df = pd.DataFrame(valid_rows)
        quarantined_count = len(quarantine_objects)
        valid_count = len(valid_rows)

        # Update PipelineRun status
        run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
        if run_record:
            run_record.valid_rows = valid_count
            run_record.quarantined_rows = quarantined_count
            run_record.current_stage = "VALIDATION_COMPLETED"
            summary = run_record.metrics_summary or {}
            summary["validation"] = {
                "total_inspected": len(raw_entries),
                "valid_count": valid_count,
                "quarantined_count": quarantined_count,
                "error_breakdown": error_counters
            }
            run_record.metrics_summary = summary
            self.db.commit()

        validation_stats = {
            "total_inspected": len(raw_entries),
            "valid_count": valid_count,
            "quarantined_count": quarantined_count,
            "error_breakdown": error_counters
        }

        logger.info(
            f"Validation completed for batch {batch_id}: {valid_count} valid, "
            f"{quarantined_count} quarantined records."
        )
        return valid_df, quarantined_count, validation_stats

    def _validate_record(self, record: Dict[str, Any]) -> List[Tuple[str, str, str]]:
        """
        Validates an individual record against all schema and business rules.
        Returns a list of (error_code, error_message, field_name) tuples.
        """
        errors = []

        # 1. Missing Required Columns Check
        for col in self.REQUIRED_COLUMNS:
            val = record.get(col)
            if val is None or (isinstance(val, str) and not val.strip()):
                errors.append(("MISSING_REQUIRED_FIELD", f"Field '{col}' is required but was null/empty", col))

        # If primary identifying fields are missing, return immediately
        if any(err[0] == "MISSING_REQUIRED_FIELD" for err in errors):
            return errors

        # 2. Date format check
        sale_date_raw = record.get("sale_date")
        parsed_date = None
        try:
            parsed_date = pd.to_datetime(sale_date_raw)
            if pd.isna(parsed_date):
                raise ValueError("Parsed date is NaT")
            # Sanity check: date shouldn't be far in the future
            if parsed_date > datetime.utcnow() + pd.Timedelta(days=2):
                errors.append(("FUTURE_DATE_ERROR", f"Sale date {sale_date_raw} is in the future", "sale_date"))
        except Exception:
            errors.append(("INVALID_DATE_FORMAT", f"Cannot parse '{sale_date_raw}' as valid datetime", "sale_date"))

        # 3. Numeric checks: Quantity
        qty = record.get("quantity")
        try:
            qty_num = float(qty)
            if qty_num <= 0:
                errors.append(("NEGATIVE_OR_ZERO_QUANTITY", f"Quantity must be > 0, got {qty}", "quantity"))
            elif qty_num > 5000:  # Spike safeguard
                errors.append(("EXCESSIVE_QUANTITY_SPIKE", f"Quantity {qty_num} exceeds max allowed threshold 5000", "quantity"))
        except (ValueError, TypeError):
            errors.append(("INVALID_NUMERIC_QUANTITY", f"Quantity '{qty}' is not a valid number", "quantity"))

        # 4. Numeric checks: Unit Price
        price = record.get("unit_price")
        try:
            price_num = float(price)
            if price_num <= 0:
                errors.append(("NEGATIVE_OR_ZERO_PRICE", f"Unit price must be > 0, got {price}", "unit_price"))
        except (ValueError, TypeError):
            errors.append(("INVALID_NUMERIC_PRICE", f"Unit price '{price}' is not a valid number", "unit_price"))

        # 5. Discount rate range check [0.0, 1.0]
        discount = record.get("discount_rate", 0.0)
        if discount is not None:
            try:
                discount_num = float(discount)
                if discount_num < 0.0 or discount_num > 1.0:
                    errors.append(("DISCOUNT_OUT_OF_RANGE", f"Discount rate must be between 0.0 and 1.0, got {discount}", "discount_rate"))
            except (ValueError, TypeError):
                errors.append(("INVALID_DISCOUNT_VALUE", f"Discount '{discount}' is not valid numeric", "discount_rate"))

        return errors
