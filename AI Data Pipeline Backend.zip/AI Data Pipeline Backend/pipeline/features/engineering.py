import logging
from datetime import datetime
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np
from sqlalchemy.orm import Session
from sqlalchemy import func
from database.models import CleanSalesRecord, AIFeatureStore, PipelineRun

logger = logging.getLogger(__name__)

class FeatureEngineer:
    """
    Gold Layer Processing: Aggregates daily store/product transactions,
    computes time-series lag and rolling statistics, calendar indicators,
    and populates the AI Feature Store for training and inference.
    """
    def __init__(self, db_session: Session):
        self.db = db_session

    def build_and_store_features(self, batch_id: str = None) -> Tuple[int, Dict[str, Any]]:
        """
        Reads clean sales from database, aggregates daily time-series,
        computes features, and upserts into ai_feature_store.
        """
        logger.info("Extracting clean sales records for feature engineering...")
        
        # Query clean sales records
        records = self.db.query(
            CleanSalesRecord.store_id,
            CleanSalesRecord.product_id,
            func.date(CleanSalesRecord.sale_date).label("date_str"),
            CleanSalesRecord.quantity,
            CleanSalesRecord.total_amount,
            CleanSalesRecord.is_promotion
        ).all()

        if not records:
            logger.warning("No clean sales records found to compute features.")
            return 0, {"features_computed": 0}

        # Convert to DataFrame
        df_raw = pd.DataFrame([
            {
                "store_id": r.store_id,
                "product_id": r.product_id,
                "date": pd.to_datetime(r.date_str),
                "quantity": r.quantity,
                "revenue": r.total_amount,
                "is_promotion": r.is_promotion
            }
            for r in records
        ])

        # Daily aggregation per store and product
        daily_agg = df_raw.groupby(["store_id", "product_id", "date"]).agg(
            sales_quantity=("quantity", "sum"),
            sales_revenue=("revenue", "sum"),
            is_promotion_active=("is_promotion", lambda s: bool(s.any()))
        ).reset_index()

        all_feature_dfs = []

        # Compute time series features per (store_id, product_id) series
        grouped = daily_agg.groupby(["store_id", "product_id"])
        for (store_id, product_id), group in grouped:
            group = group.sort_values("date").set_index("date")

            # Reindex to continuous daily date range to preserve true lag/rolling integrity
            min_date = group.index.min()
            max_date = group.index.max()
            full_idx = pd.date_range(start=min_date, end=max_date, freq="D")
            
            reindexed = group.reindex(full_idx)
            reindexed["store_id"] = store_id
            reindexed["product_id"] = product_id
            reindexed["sales_quantity"] = reindexed["sales_quantity"].fillna(0.0)
            reindexed["sales_revenue"] = reindexed["sales_revenue"].fillna(0.0)
            reindexed["is_promotion_active"] = reindexed["is_promotion_active"].fillna(False)

            # Lags
            reindexed["lag_1_qty"] = reindexed["sales_quantity"].shift(1)
            reindexed["lag_7_qty"] = reindexed["sales_quantity"].shift(7)
            reindexed["lag_14_qty"] = reindexed["sales_quantity"].shift(14)

            # Rolling statistics (using closed='left' so target day is not leaked)
            reindexed["rolling_7_mean_qty"] = (
                reindexed["sales_quantity"].shift(1).rolling(window=7, min_periods=1).mean()
            )
            reindexed["rolling_7_std_qty"] = (
                reindexed["sales_quantity"].shift(1).rolling(window=7, min_periods=2).std().fillna(0.0)
            )
            reindexed["rolling_14_mean_qty"] = (
                reindexed["sales_quantity"].shift(1).rolling(window=14, min_periods=1).mean()
            )
            reindexed["rolling_30_mean_qty"] = (
                reindexed["sales_quantity"].shift(1).rolling(window=30, min_periods=1).mean()
            )

            # Calendar features
            reindexed["day_of_week"] = reindexed.index.weekday
            reindexed["day_of_month"] = reindexed.index.day
            reindexed["month"] = reindexed.index.month
            reindexed["is_weekend"] = reindexed["day_of_week"].isin([5, 6])

            reindexed = reindexed.reset_index().rename(columns={"index": "feature_date"})
            all_feature_dfs.append(reindexed)

        final_features_df = pd.concat(all_feature_dfs, ignore_index=True)

        # Clear old features to avoid stale duplicates or primary key conflicts
        self.db.query(AIFeatureStore).delete()
        self.db.commit()

        # Batch insert into AIFeatureStore
        feature_objects = []
        for _, row in final_features_df.iterrows():
            feat = AIFeatureStore(
                store_id=str(row["store_id"]),
                product_id=str(row["product_id"]),
                feature_date=row["feature_date"].to_pydatetime(),
                sales_quantity=float(row["sales_quantity"]),
                sales_revenue=float(row["sales_revenue"]),
                lag_1_qty=float(row["lag_1_qty"]) if pd.notna(row["lag_1_qty"]) else 0.0,
                lag_7_qty=float(row["lag_7_qty"]) if pd.notna(row["lag_7_qty"]) else 0.0,
                lag_14_qty=float(row["lag_14_qty"]) if pd.notna(row["lag_14_qty"]) else 0.0,
                rolling_7_mean_qty=float(row["rolling_7_mean_qty"]) if pd.notna(row["rolling_7_mean_qty"]) else 0.0,
                rolling_7_std_qty=float(row["rolling_7_std_qty"]) if pd.notna(row["rolling_7_std_qty"]) else 0.0,
                rolling_14_mean_qty=float(row["rolling_14_mean_qty"]) if pd.notna(row["rolling_14_mean_qty"]) else 0.0,
                rolling_30_mean_qty=float(row["rolling_30_mean_qty"]) if pd.notna(row["rolling_30_mean_qty"]) else 0.0,
                day_of_week=int(row["day_of_week"]),
                day_of_month=int(row["day_of_month"]),
                month=int(row["month"]),
                is_weekend=bool(row["is_weekend"]),
                is_promotion_active=bool(row["is_promotion_active"]),
                created_at=datetime.utcnow()
            )
            feature_objects.append(feat)

            if len(feature_objects) >= 1000:
                self.db.bulk_save_objects(feature_objects)
                self.db.commit()
                feature_objects = []

        if feature_objects:
            self.db.bulk_save_objects(feature_objects)
            self.db.commit()

        # Update PipelineRun if batch_id provided
        if batch_id:
            run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
            if run_record:
                run_record.current_stage = "FEATURE_ENG_COMPLETED"
                summary = run_record.metrics_summary or {}
                summary["feature_engineering"] = {
                    "total_feature_rows": len(final_features_df),
                    "series_count": len(grouped),
                    "date_span": f"{final_features_df['feature_date'].min().strftime('%Y-%m-%d')} to {final_features_df['feature_date'].max().strftime('%Y-%m-%d')}"
                }
                run_record.metrics_summary = summary
                self.db.commit()

        stats = {
            "total_feature_rows": len(final_features_df),
            "series_count": len(grouped),
        }
        logger.info(f"Gold feature store loaded with {len(final_features_df)} feature vectors.")
        return len(final_features_df), stats
