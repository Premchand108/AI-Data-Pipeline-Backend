import os
import random
import uuid
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

STORES = [
    {"store_id": "STORE_001", "name": "Downtown Flagship", "base_volume": 1.4},
    {"store_id": "STORE_002", "name": "Uptown Mall", "base_volume": 1.0},
    {"store_id": "STORE_003", "name": "Suburban Express", "base_volume": 0.8},
]

PRODUCTS = [
    {"product_id": "PROD_ELEC_101", "category": "Electronics", "base_price": 299.99, "popularity": 1.2},
    {"product_id": "PROD_ELEC_102", "category": "Electronics", "base_price": 79.99, "popularity": 2.5},
    {"product_id": "PROD_APPR_201", "category": "Apparel", "base_price": 49.99, "popularity": 3.0},
    {"product_id": "PROD_APPR_202", "category": "Apparel", "base_price": 89.99, "popularity": 1.8},
    {"product_id": "PROD_GROC_301", "category": "Groceries", "base_price": 12.50, "popularity": 5.0},
    {"product_id": "PROD_HOME_401", "category": "Home Goods", "base_price": 34.99, "popularity": 2.1},
]

def generate_sales_data(
    start_date: datetime = None,
    num_days: int = 60,
    inject_anomalies: bool = True,
    anomaly_rate: float = 0.04,
    random_seed: int = 42
) -> pd.DataFrame:
    """
    Generate realistic multi-store sales data with realistic seasonality,
    trend, promotional spikes, and optional anomalous dirty records.
    """
    np.random.seed(random_seed)
    random.seed(random_seed)

    if start_date is None:
        start_date = datetime.utcnow() - timedelta(days=num_days)

    records = []

    for day_idx in range(num_days):
        current_date = start_date + timedelta(days=day_idx)
        dow = current_date.weekday()  # 0=Monday, 6=Sunday
        
        # Weekend multiplier (higher sales on Fri, Sat, Sun)
        weekend_boost = 1.35 if dow in (4, 5, 6) else 1.0
        # Gentle growth trend over time
        trend_factor = 1.0 + (day_idx / num_days) * 0.15
        
        # Occasional promotional campaign days (e.g., every 14 days)
        is_promo_day = (day_idx % 14 == 0) or (day_idx % 14 == 1)

        for store in STORES:
            store_mult = store["base_volume"]
            
            for prod in PRODUCTS:
                prod_popularity = prod["popularity"]
                base_price = prod["base_price"]
                category = prod["category"]

                # Expected number of daily transactions for this store & product
                lambda_tx = max(1, int(4 * store_mult * prod_popularity * weekend_boost * (1.5 if is_promo_day else 1.0)))
                tx_count = np.random.poisson(lam=lambda_tx)

                for _ in range(tx_count):
                    tx_id = f"TXN_{uuid.uuid4().hex[:10].upper()}"
                    
                    # Typical quantity purchased
                    if category == "Groceries":
                        qty = int(np.random.choice([1, 2, 3, 4, 5], p=[0.4, 0.3, 0.15, 0.1, 0.05]))
                    elif category == "Electronics":
                        qty = int(np.random.choice([1, 2], p=[0.9, 0.1]))
                    else:
                        qty = int(np.random.choice([1, 2, 3], p=[0.7, 0.2, 0.1]))

                    # Discount simulation
                    if is_promo_day and random.random() < 0.7:
                        discount = round(random.choice([0.10, 0.15, 0.20, 0.25]), 2)
                        is_promo = True
                    else:
                        discount = 0.0
                        is_promo = False

                    # Price with small variance
                    unit_price = round(base_price * (1.0 + np.random.normal(0, 0.02)), 2)
                    
                    record = {
                        "transaction_id": tx_id,
                        "store_id": store["store_id"],
                        "product_id": prod["product_id"],
                        "category": category,
                        "sale_date": current_date.strftime("%Y-%m-%d %H:%M:%S"),
                        "quantity": qty,
                        "unit_price": unit_price,
                        "discount_rate": discount,
                        "is_promotion": is_promo,
                    }

                    # Inject dirty data for testing data validation gate
                    if inject_anomalies and random.random() < anomaly_rate:
                        anomaly_type = random.choice([
                            "negative_price",
                            "negative_quantity",
                            "missing_product_id",
                            "invalid_date",
                            "out_of_range_discount",
                            "extreme_quantity_spike"
                        ])
                        if anomaly_type == "negative_price":
                            record["unit_price"] = -abs(unit_price)
                        elif anomaly_type == "negative_quantity":
                            record["quantity"] = -qty
                        elif anomaly_type == "missing_product_id":
                            record["product_id"] = None
                        elif anomaly_type == "invalid_date":
                            record["sale_date"] = "INVALID-DATE-STRING"
                        elif anomaly_type == "out_of_range_discount":
                            record["discount_rate"] = 1.85  # Discount > 100%
                        elif anomaly_type == "extreme_quantity_spike":
                            record["quantity"] = 99999

                    records.append(record)

    df = pd.DataFrame(records)
    return df

def generate_and_save_mock_csv(
    file_path: str,
    num_days: int = 60,
    inject_anomalies: bool = True
) -> str:
    """Generate mock dataset and save directly to CSV."""
    os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
    df = generate_sales_data(num_days=num_days, inject_anomalies=inject_anomalies)
    df.to_csv(file_path, index=False)
    return file_path
