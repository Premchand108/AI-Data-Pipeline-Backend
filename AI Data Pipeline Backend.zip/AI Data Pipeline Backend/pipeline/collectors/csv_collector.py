import os
import json
import hashlib
import logging
from datetime import datetime
from typing import Dict, Any, Tuple
import pandas as pd
from sqlalchemy.orm import Session
from database.models import RawSalesIngestion, PipelineRun

logger = logging.getLogger(__name__)

class CSVDataCollector:
    """
    Collector responsible for ingesting CSV files or incoming data feeds,
    creating the Bronze layer entries, and initializing pipeline run tracking.
    """
    def __init__(self, db_session: Session):
        self.db = db_session

    def ingest_file(
        self,
        file_path: str,
        batch_id: str,
        source_channel: str = "pos_batch_csv"
    ) -> Tuple[int, PipelineRun]:
        """
        Reads CSV file, serializes rows into the Bronze raw_sales_ingestion table,
        and creates/updates a PipelineRun tracker.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Input file not found: {file_path}")

        logger.info(f"Starting ingestion for batch {batch_id} from {file_path}")
        df = pd.read_csv(file_path)
        total_rows = len(df)

        # Initialize or retrieve pipeline run record
        run_record = self.db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
        if not run_record:
            run_record = PipelineRun(
                batch_id=batch_id,
                pipeline_name="nightly_sales_forecast_pipeline",
                status="RUNNING",
                current_stage="INGESTION",
                total_raw_rows=total_rows,
                start_time=datetime.utcnow()
            )
            self.db.add(run_record)
            self.db.commit()

        raw_entities = []
        for idx, row in df.iterrows():
            row_dict = row.to_dict()
            # Handle NaN / NaT values for clean JSON serialization
            cleaned_dict = {k: (None if pd.isna(v) else v) for k, v in row_dict.items()}
            payload_str = json.dumps(cleaned_dict, default=str)
            row_hash = hashlib.sha256(payload_str.encode("utf-8")).hexdigest()

            raw_entry = RawSalesIngestion(
                batch_id=batch_id,
                source_channel=source_channel,
                file_name=os.path.basename(file_path),
                row_number=int(idx) + 1,
                raw_payload=payload_str,
                row_hash=row_hash,
                ingested_at=datetime.utcnow()
            )
            raw_entities.append(raw_entry)

            # Insert in chunks to optimize memory and DB throughput
            if len(raw_entities) >= 1000:
                self.db.bulk_save_objects(raw_entities)
                self.db.commit()
                raw_entities = []

        if raw_entities:
            self.db.bulk_save_objects(raw_entities)
            self.db.commit()

        run_record.total_raw_rows = total_rows
        run_record.current_stage = "INGESTION_COMPLETED"
        self.db.commit()

        logger.info(f"Successfully ingested {total_rows} raw records for batch {batch_id}")
        return total_rows, run_record
