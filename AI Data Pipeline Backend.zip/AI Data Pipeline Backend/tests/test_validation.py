import pytest
import json
import pandas as pd
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database.models import Base, RawSalesIngestion, QuarantinedRecord
from pipeline.validation.validator import DataQualityValidator

@pytest.fixture
def in_memory_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()

def test_data_quality_validator_passes_valid_data(in_memory_db):
    batch_id = "TEST_BATCH_VALID"
    validator = DataQualityValidator(in_memory_db)

    # Ingest clean row
    raw_payload = json.dumps({
        "transaction_id": "TX_001",
        "store_id": "STORE_001",
        "product_id": "PROD_001",
        "category": "Electronics",
        "sale_date": "2026-03-10 14:30:00",
        "quantity": 2,
        "unit_price": 49.99,
        "discount_rate": 0.1,
        "is_promotion": False
    })
    raw_rec = RawSalesIngestion(
        batch_id=batch_id,
        raw_payload=raw_payload,
        row_number=1
    )
    in_memory_db.add(raw_rec)
    in_memory_db.commit()

    valid_df, quarantined_count, stats = validator.validate_batch(batch_id)

    assert quarantined_count == 0
    assert len(valid_df) == 1
    assert valid_df.iloc[0]["transaction_id"] == "TX_001"

def test_data_quality_validator_quarantines_anomalies(in_memory_db):
    batch_id = "TEST_BATCH_ANOMALIES"
    validator = DataQualityValidator(in_memory_db)

    # Ingest dirty rows
    dirty_records = [
        {"transaction_id": "TX_NEG_PRICE", "store_id": "STORE_001", "product_id": "PROD_001", "sale_date": "2026-03-10", "quantity": 1, "unit_price": -10.0},
        {"transaction_id": "TX_NEG_QTY", "store_id": "STORE_001", "product_id": "PROD_001", "sale_date": "2026-03-10", "quantity": -5, "unit_price": 20.0},
        {"transaction_id": "TX_BAD_DISCOUNT", "store_id": "STORE_001", "product_id": "PROD_001", "sale_date": "2026-03-10", "quantity": 1, "unit_price": 20.0, "discount_rate": 1.5},
        {"transaction_id": "TX_MISSING_PROD", "store_id": "STORE_001", "product_id": None, "sale_date": "2026-03-10", "quantity": 1, "unit_price": 20.0},
    ]

    for idx, rec in enumerate(dirty_records):
        raw_rec = RawSalesIngestion(
            batch_id=batch_id,
            raw_payload=json.dumps(rec),
            row_number=idx + 1
        )
        in_memory_db.add(raw_rec)
    in_memory_db.commit()

    valid_df, quarantined_count, stats = validator.validate_batch(batch_id)

    assert len(valid_df) == 0
    assert quarantined_count == 4
    
    # Verify records stored in QuarantinedRecord table
    q_records = in_memory_db.query(QuarantinedRecord).filter(QuarantinedRecord.batch_id == batch_id).all()
    assert len(q_records) == 4
    error_codes = [q.error_code for q in q_records]
    assert "NEGATIVE_OR_ZERO_PRICE" in error_codes
    assert "NEGATIVE_OR_ZERO_QUANTITY" in error_codes
    assert "DISCOUNT_OUT_OF_RANGE" in error_codes
    assert "MISSING_REQUIRED_FIELD" in error_codes
