import pytest
from fastapi.testclient import TestClient
from api.main import app
from database.connection import init_db

@pytest.fixture(scope="module")
def client():
    init_db()
    with TestClient(app) as c:
        yield c

def test_api_health_check(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] in ("HEALTHY", "DEGRADED")
    assert "database_connected" in data

def test_api_data_quality_summary(client):
    response = client.get("/api/data-quality/summary")
    assert response.status_code == 200
    data = response.json()
    assert "total_raw_ingested" in data
    assert "clean_rate_pct" in data
    assert "quarantine_rate_pct" in data

def test_api_list_pipeline_runs(client):
    response = client.get("/api/pipeline/runs?limit=5")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)

def test_api_registered_models(client):
    response = client.get("/api/forecasts/models")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
