import pytest
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database.models import Base, CleanSalesRecord
from pipeline.cleaning.cleaner import DataCleaner

@pytest.fixture
def in_memory_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()

def test_data_cleaner_deduplication_and_derived_amount(in_memory_db):
    cleaner = DataCleaner(in_memory_db)
    batch_id = "TEST_CLEANING_BATCH"

    # Input data with duplicate transaction_id and lowercase identifiers
    df = pd.DataFrame([
        {
            "transaction_id": "TX_100",
            "store_id": "store_01",
            "product_id": "prod_a",
            "category": "electronics",
            "sale_date": "2026-04-01 10:00:00",
            "quantity": 2,
            "unit_price": 100.0,
            "discount_rate": 0.10,
            "is_promotion": False
        },
        # Duplicate transaction_id with updated price
        {
            "transaction_id": "TX_100",
            "store_id": "store_01",
            "product_id": "prod_a",
            "category": "electronics",
            "sale_date": "2026-04-01 10:00:00",
            "quantity": 3,
            "unit_price": 100.0,
            "discount_rate": 0.20,
            "is_promotion": True
        },
        {
            "transaction_id": "TX_101",
            "store_id": "store_02",
            "product_id": "prod_b",
            "category": "apparel",
            "sale_date": "2026-04-01 11:00:00",
            "quantity": 1,
            "unit_price": 50.0,
            "discount_rate": 0.0,
            "is_promotion": False
        }
    ])

    stored_count, stats = cleaner.clean_and_store(df, batch_id)

    # Dedup should drop 1 duplicate, leaving 2 records
    assert stored_count == 2
    assert stats["deduplicated_dropped"] == 1

    # Check clean records in database
    records = in_memory_db.query(CleanSalesRecord).filter(CleanSalesRecord.batch_id == batch_id).all()
    assert len(records) == 2

    tx_100 = [r for r in records if r.transaction_id == "TX_100"][0]
    # Check casing normalized
    assert tx_100.store_id == "STORE_01"
    assert tx_100.product_id == "PROD_A"
    assert tx_100.category == "Electronics"
    # Check derived calculation: quantity (3) * unit_price (100) * (1 - 0.20) = 240.0
    assert tx_100.total_amount == 240.0
