import pytest
from datetime import datetime, timedelta
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database.models import Base, CleanSalesRecord, AIFeatureStore
from pipeline.features.engineering import FeatureEngineer

@pytest.fixture
def in_memory_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()

def test_feature_engineering_lags_and_rolling_metrics(in_memory_db):
    # Populate sequential daily clean sales records for 20 days
    base_date = datetime(2026, 1, 1)
    clean_records = []
    
    for day in range(20):
        sale_date = base_date + timedelta(days=day)
        qty = 10 if day % 2 == 0 else 20
        clean_rec = CleanSalesRecord(
            batch_id="TEST_FE_BATCH",
            transaction_id=f"TX_{day}",
            store_id="STORE_001",
            product_id="PROD_001",
            category="Apparel",
            sale_date=sale_date,
            quantity=qty,
            unit_price=50.0,
            discount_rate=0.0,
            total_amount=qty * 50.0,
            is_promotion=False,
            cleaned_at=datetime.utcnow()
        )
        clean_records.append(clean_rec)

    in_memory_db.bulk_save_objects(clean_records)
    in_memory_db.commit()

    fe = FeatureEngineer(in_memory_db)
    feature_count, stats = fe.build_and_store_features(batch_id="TEST_FE_BATCH")

    assert feature_count == 20

    # Query computed features
    stored_features = in_memory_db.query(AIFeatureStore).order_by(AIFeatureStore.feature_date.asc()).all()
    assert len(stored_features) == 20

    # Test lag_1 on day 1 (index 1)
    day_0 = stored_features[0]
    day_1 = stored_features[1]
    assert day_1.lag_1_qty == day_0.sales_quantity

    # Test rolling 7 mean on day 8 (index 8)
    day_8 = stored_features[8]
    assert day_8.rolling_7_mean_qty > 0.0
    assert day_8.day_of_week in range(0, 7)
