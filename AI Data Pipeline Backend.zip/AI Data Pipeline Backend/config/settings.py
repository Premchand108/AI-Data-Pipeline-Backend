import os
from typing import Optional

class Settings:
    PROJECT_NAME: str = "AI Data Pipeline Backend"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    DEBUG: bool = os.getenv("DEBUG", "True").lower() in ("true", "1", "yes")
    
    # Database Settings (PostgreSQL default with automatic SQLite fallback)
    # E.g., postgresql://postgres:postgres@localhost:5432/ai_data_pipeline
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./data_pipeline.db")
    
    # Celery & Broker Settings
    CELERY_BROKER_URL: str = os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0")
    CELERY_RESULT_BACKEND: str = os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/0")
    
    # Storage Paths
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_DIR: str = os.path.join(BASE_DIR, "data")
    RAW_DATA_DIR: str = os.path.join(BASE_DIR, "data", "raw")
    MODEL_STORE_DIR: str = os.path.join(BASE_DIR, "data", "models")
    
    # Pipeline Parameters
    BATCH_SIZE: int = int(os.getenv("BATCH_SIZE", "1000"))
    FORECAST_HORIZON_DAYS: int = int(os.getenv("FORECAST_HORIZON_DAYS", "7"))
    OUTLIER_IQR_FACTOR: float = float(os.getenv("OUTLIER_IQR_FACTOR", "3.0"))
    
    # Nightly Pipeline Cron Settings (Celery Beat)
    NIGHTLY_SCHEDULE_HOUR: int = int(os.getenv("NIGHTLY_SCHEDULE_HOUR", "0"))
    NIGHTLY_SCHEDULE_MINUTE: int = int(os.getenv("NIGHTLY_SCHEDULE_MINUTE", "0"))

settings = Settings()

# Ensure directories exist
os.makedirs(settings.DATA_DIR, exist_ok=True)
os.makedirs(settings.RAW_DATA_DIR, exist_ok=True)
os.makedirs(settings.MODEL_STORE_DIR, exist_ok=True)
