import os
import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database.connection import get_db, SessionFactory
from database.models import PipelineRun
from pipeline.orchestrator import PipelineOrchestrator
from pipeline.collectors.mock_data_generator import generate_and_save_mock_csv
from config.settings import settings

router = APIRouter(prefix="/api/pipeline", tags=["Pipeline Execution"])

class TriggerPipelineRequest(BaseModel):
    batch_id: Optional[str] = None
    csv_file_path: Optional[str] = None
    generate_mock: bool = True
    days_history: int = 60
    retrain_model: bool = True
    mode: str = "direct"  # "direct" or "celery"

@router.post("/trigger")
def trigger_pipeline(
    req: TriggerPipelineRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Trigger end-to-end data pipeline execution.
    Supports synchronous 'direct' execution or asynchronous background/celery dispatch.
    """
    batch_id = req.batch_id or f"BATCH_API_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    
    file_path = req.csv_file_path
    if (not file_path or not os.path.exists(file_path)) and req.generate_mock:
        file_path = os.path.join(settings.DATA_DIR, f"sales_{batch_id}.csv")
        generate_and_save_mock_csv(file_path, num_days=req.days_history, inject_anomalies=True)

    if req.mode == "celery":
        try:
            from celery_app.tasks import task_run_nightly_pipeline
            async_task = task_run_nightly_pipeline.delay(
                batch_id=batch_id,
                csv_file_path=file_path,
                generate_sample_if_missing=False
            )
            return {
                "message": "Pipeline queued in Celery worker",
                "batch_id": batch_id,
                "celery_task_id": async_task.id,
                "mode": "celery"
            }
        except Exception as e:
            # Fallback to direct background task if Celery broker unavailable
            def run_sync(b_id, f_path, retrain):
                session = SessionFactory()
                orch = PipelineOrchestrator(db=session)
                try:
                    orch.run_nightly_pipeline(batch_id=b_id, csv_file_path=f_path, retrain_model=retrain)
                finally:
                    orch.close()

            background_tasks.add_task(run_sync, batch_id, file_path, req.retrain_model)
            return {
                "message": f"Celery queue unavailable ({str(e)}). Dispatched to FastAPI background worker.",
                "batch_id": batch_id,
                "mode": "background_fallback"
            }

    # Direct synchronous run
    orchestrator = PipelineOrchestrator(db=db)
    result = orchestrator.run_nightly_pipeline(
        batch_id=batch_id,
        csv_file_path=file_path,
        retrain_model=req.retrain_model
    )
    return result

@router.get("/runs")
def list_pipeline_runs(
    limit: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """List execution history and audit telemetry of pipeline runs."""
    query = db.query(PipelineRun).order_by(PipelineRun.start_time.desc())
    if status:
        query = query.filter(PipelineRun.status == status.upper())
    runs = query.limit(limit).all()

    return [
        {
            "id": r.id,
            "batch_id": r.batch_id,
            "pipeline_name": r.pipeline_name,
            "status": r.status,
            "current_stage": r.current_stage,
            "total_raw_rows": r.total_raw_rows,
            "valid_rows": r.valid_rows,
            "quarantined_rows": r.quarantined_rows,
            "start_time": r.start_time.isoformat() if r.start_time else None,
            "end_time": r.end_time.isoformat() if r.end_time else None,
            "duration_seconds": r.duration_seconds,
            "error_message": r.error_message,
            "metrics_summary": r.metrics_summary
        }
        for r in runs
    ]

@router.get("/runs/{batch_id}")
def get_pipeline_run_details(batch_id: str, db: Session = Depends(get_db)):
    """Get detailed telemetry and stage breakdown for a specific batch run."""
    run = db.query(PipelineRun).filter(PipelineRun.batch_id == batch_id).first()
    if not run:
        raise HTTPException(status_code=404, detail=f"Pipeline run for batch {batch_id} not found.")

    return {
        "batch_id": run.batch_id,
        "pipeline_name": run.pipeline_name,
        "status": run.status,
        "current_stage": run.current_stage,
        "total_raw_rows": run.total_raw_rows,
        "valid_rows": run.valid_rows,
        "quarantined_rows": run.quarantined_rows,
        "start_time": run.start_time.isoformat() if run.start_time else None,
        "end_time": run.end_time.isoformat() if run.end_time else None,
        "duration_seconds": run.duration_seconds,
        "error_message": run.error_message,
        "metrics_summary": run.metrics_summary
    }
