from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func

from database.connection import get_db
from database.models import QuarantinedRecord, CleanSalesRecord, AIFeatureStore, RawSalesIngestion

router = APIRouter(prefix="/api/data-quality", tags=["Data Quality & Features"])

@router.get("/summary")
def get_data_quality_summary(db: Session = Depends(get_db)):
    """
    Returns high-level data health metrics across Bronze, Silver, and Quarantine layers:
    total ingested, clean vs quarantined records, and breakdown of error codes.
    """
    total_raw = db.query(RawSalesIngestion).count()
    total_clean = db.query(CleanSalesRecord).count()
    total_quarantined = db.query(QuarantinedRecord).count()

    # Aggregate quarantine breakdown by error_code
    error_breakdown_raw = (
        db.query(QuarantinedRecord.error_code, func.count(QuarantinedRecord.id))
        .group_by(QuarantinedRecord.error_code)
        .all()
    )
    error_breakdown = {code: count for code, count in error_breakdown_raw}

    # Field breakdown
    field_breakdown_raw = (
        db.query(QuarantinedRecord.field_name, func.count(QuarantinedRecord.id))
        .group_by(QuarantinedRecord.field_name)
        .all()
    )
    field_breakdown = {field or "General": count for field, count in field_breakdown_raw}

    clean_rate = round((total_clean / total_raw * 100), 2) if total_raw > 0 else 100.0
    quarantine_rate = round((total_quarantined / total_raw * 100), 2) if total_raw > 0 else 0.0

    return {
        "total_raw_ingested": total_raw,
        "total_clean_stored": total_clean,
        "total_quarantined": total_quarantined,
        "clean_rate_pct": clean_rate,
        "quarantine_rate_pct": quarantine_rate,
        "error_codes_breakdown": error_breakdown,
        "fields_breakdown": field_breakdown
    }

@router.get("/quarantined")
def get_quarantined_records(
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    batch_id: Optional[str] = None,
    error_code: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Inspect individual records isolated by the Data Quality Gate with full error diagnosis.
    """
    query = db.query(QuarantinedRecord).order_by(QuarantinedRecord.quarantined_at.desc())
    if batch_id:
        query = query.filter(QuarantinedRecord.batch_id == batch_id)
    if error_code:
        query = query.filter(QuarantinedRecord.error_code == error_code)

    total_count = query.count()
    records = query.offset(offset).limit(limit).all()

    return {
        "total_matches": total_count,
        "limit": limit,
        "offset": offset,
        "records": [
            {
                "id": r.id,
                "batch_id": r.batch_id,
                "field_name": r.field_name,
                "error_code": r.error_code,
                "error_message": r.error_message,
                "invalid_payload": r.invalid_payload,
                "quarantined_at": r.quarantined_at.isoformat()
            }
            for r in records
        ]
    }

@router.get("/feature-store")
def get_feature_store_summary(
    limit: int = Query(30, ge=1, le=200),
    store_id: Optional[str] = None,
    product_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Query the Gold Layer AI Feature Store containing engineered lags, rolling averages,
    and calendar features for model training and forecasting.
    """
    query = db.query(AIFeatureStore).order_by(AIFeatureStore.feature_date.desc())
    if store_id:
        query = query.filter(AIFeatureStore.store_id == store_id.upper())
    if product_id:
        query = query.filter(AIFeatureStore.product_id == product_id.upper())

    total = query.count()
    features = query.limit(limit).all()

    return {
        "total_feature_rows": total,
        "samples": [
            {
                "store_id": f.store_id,
                "product_id": f.product_id,
                "feature_date": f.feature_date.strftime("%Y-%m-%d"),
                "sales_quantity": f.sales_quantity,
                "sales_revenue": f.sales_revenue,
                "lag_1_qty": f.lag_1_qty,
                "lag_7_qty": f.lag_7_qty,
                "rolling_7_mean_qty": f.rolling_7_mean_qty,
                "rolling_7_std_qty": f.rolling_7_std_qty,
                "rolling_30_mean_qty": f.rolling_30_mean_qty,
                "day_of_week": f.day_of_week,
                "is_weekend": f.is_weekend,
                "is_promotion_active": f.is_promotion_active
            }
            for f in features
        ]
    }
