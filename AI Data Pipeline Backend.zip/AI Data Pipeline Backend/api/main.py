import os
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from config.settings import settings
from database.connection import init_db, engine
from api.routes.pipeline_routes import router as pipeline_router
from api.routes.quality_routes import router as quality_router
from api.routes.forecast_routes import router as forecast_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger("FastAPI")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Ensure database schema is ready
    logger.info("Initializing database tables on API startup...")
    init_db()
    yield
    # Shutdown logic if needed
    logger.info("Shutting down API server...")

app = FastAPI(
    title="AI Data Pipeline Backend",
    description="Automated End-to-End Sales Data Collection, Validation Gate, Cleaning, Feature Engineering, and AI Time-Series Forecaster",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(pipeline_router)
app.include_router(quality_router)
app.include_router(forecast_router)

# Healthcheck Endpoint
@app.get("/api/health", tags=["System Health"])
def health_check():
    """Health check verifying database connection and service availability."""
    db_ok = False
    try:
        with engine.connect() as conn:
            db_ok = True
    except Exception as e:
        logger.error(f"Healthcheck DB connection error: {e}")

    return {
        "status": "HEALTHY" if db_ok else "DEGRADED",
        "database_connected": db_ok,
        "database_url": settings.DATABASE_URL.split("@")[-1] if "@" in settings.DATABASE_URL else settings.DATABASE_URL,
        "broker_configured": settings.CELERY_BROKER_URL,
        "model_dir_exists": os.path.exists(settings.MODEL_STORE_DIR)
    }

# Serve Dashboard Frontend
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/", include_in_schema=False)
@app.get("/dashboard", include_in_schema=False)
def serve_dashboard():
    index_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "AI Data Pipeline Backend API is running. Visit /docs for OpenAPI specifications."}
