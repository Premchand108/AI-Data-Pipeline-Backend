import os
import logging
from celery import Celery
from config.settings import settings

logger = logging.getLogger(__name__)

# Initialize Celery Application
celery_app = Celery(
    "ai_data_pipeline",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["celery_app.tasks"]
)

# Celery Configuration
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=3600,         # 1 hour hard limit
    task_soft_time_limit=3000,    # 50 min soft limit
    worker_prefetch_multiplier=1, # Fair task dispatching
    task_acks_late=True,          # Reliable task acknowledgment
    task_reject_on_worker_lost=True,
    broker_connection_retry_on_startup=True
)

# Celery Beat Periodic Schedule
celery_app.conf.beat_schedule = {
    "run-nightly-sales-pipeline": {
        "task": "celery_app.tasks.task_run_nightly_pipeline",
        "schedule": 86400.0,  # Runs every 24 hours (nightly)
        "kwargs": {
            "batch_id": None,
            "csv_file_path": None,
            "generate_sample_if_missing": True
        }
    },
    "hourly-data-quality-healthcheck": {
        "task": "celery_app.tasks.task_data_quality_healthcheck",
        "schedule": 3600.0,  # Every hour
    }
}
