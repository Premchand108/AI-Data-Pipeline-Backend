import os
import uuid
import logging
from datetime import datetime
from typing import Dict, Any, Optional

from celery_app.celery_worker import celery_app
from database.connection import SessionFactory
from database.models import PipelineRun, QuarantinedRecord
from pipeline.orchestrator import PipelineOrchestrator
from pipeline.collectors.mock_data_generator import generate_and_save_mock_csv
from config.settings import settings

logger = logging.getLogger(__name__)

@celery_app.task(bind=True, max_retries=3, default_retry_delay=30, retry_backoff=True)
def task_run_nightly_pipeline(
    self,
    batch_id: Optional[str] = None,
    csv_file_path: Optional[str] = None,
    generate_sample_if_missing: bool = True
) -> Dict[str, Any]:
    """
    Celery task orchestrating the complete nightly data pipeline:
    1. Collects/Ingests batch
    2. Validates against Data Quality Gate
    3. Cleans, standardizes, deduplicates into Silver layer
    4. Computes time-series lags & rolling features into Gold store
    5. Retrains/updates AI Forecasting Model
    6. Generates multi-day forecast predictions
    7. Records audit telemetry
    """
    if not batch_id:
        batch_id = f"BATCH_CELERY_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

    logger.info(f"[Celery Worker] Starting task_run_nightly_pipeline for {batch_id} (Task ID: {self.request.id})")

    # If no file provided and configured to generate sample, create fresh daily batch
    if not csv_file_path or not os.path.exists(csv_file_path):
        if generate_sample_if_missing:
            sample_file = os.path.join(settings.DATA_DIR, f"daily_sales_{batch_id}.csv")
            generate_and_save_mock_csv(sample_file, num_days=60, inject_anomalies=True)
            csv_file_path = sample_file
            logger.info(f"Generated new mock daily sales batch at {sample_file}")

    db = SessionFactory()
    orchestrator = PipelineOrchestrator(db=db)

    try:
        self.update_state(state="PROGRESS", meta={"stage": "PIPELINE_ORCHESTRATION_STARTED", "batch_id": batch_id})
        result = orchestrator.run_nightly_pipeline(
            batch_id=batch_id,
            csv_file_path=csv_file_path,
            retrain_model=True
        )

        if result.get("status") == "FAILED":
            raise RuntimeError(f"Pipeline execution reported failure: {result.get('error')}")

        return result
    except Exception as exc:
        logger.error(f"[Celery Worker] Error executing batch {batch_id}: {exc}", exc_info=True)
        # Celery retry with exponential backoff
        raise self.retry(exc=exc)
    finally:
        orchestrator.close()


@celery_app.task(bind=True)
def task_data_quality_healthcheck(self) -> Dict[str, Any]:
    """
    Periodic healthcheck task to monitor quarantine rates,
    flag spikes in dirty data, and report pipeline stability.
    """
    db = SessionFactory()
    try:
        total_quarantined = db.query(QuarantinedRecord).count()
        recent_runs = db.query(PipelineRun).order_by(PipelineRun.start_time.desc()).limit(5).all()

        runs_summary = [
            {
                "batch_id": r.batch_id,
                "status": r.status,
                "duration": r.duration_seconds,
                "valid": r.valid_rows,
                "quarantined": r.quarantined_rows
            }
            for r in recent_runs
        ]

        logger.info(f"[Healthcheck] Total quarantined records: {total_quarantined}. Recent runs: {len(recent_runs)}")
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "total_quarantined_all_time": total_quarantined,
            "recent_runs": runs_summary
        }
    finally:
        db.close()
