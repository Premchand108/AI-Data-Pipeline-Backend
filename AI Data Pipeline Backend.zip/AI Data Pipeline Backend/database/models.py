from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Boolean, Text, JSON, Index, ForeignKey
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

def utc_now():
    return datetime.now(timezone.utc)


class RawSalesIngestion(Base):
    """
    Bronze Layer: Raw landing table for ingested sales transactions.
    Preserves verbatim external data for lineage and replayability.
    """
    __tablename__ = "raw_sales_ingestion"

    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(64), index=True, nullable=False)
    source_channel = Column(String(64), default="pos_file_upload")
    file_name = Column(String(255), nullable=True)
    row_number = Column(Integer, nullable=True)
    raw_payload = Column(Text, nullable=False)  # JSON serialized original row
    row_hash = Column(String(64), nullable=True, index=True)
    ingested_at = Column(DateTime, default=utc_now, nullable=False)

    __table_args__ = (
        Index("idx_raw_batch_row", "batch_id", "row_number"),
    )


class QuarantinedRecord(Base):
    """
    Data Quality Gate: Quarantined records that failed validation.
    Allows dirty data to be logged, inspected, and repaired without crashing the pipeline.
    """
    __tablename__ = "quarantined_records"

    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(64), index=True, nullable=False)
    raw_record_id = Column(Integer, nullable=True)
    field_name = Column(String(64), nullable=True)
    error_code = Column(String(64), nullable=False)  # e.g., INVALID_VALUE, MISSING_REQUIRED, RANGE_VIOLATION
    error_message = Column(Text, nullable=False)
    invalid_payload = Column(Text, nullable=False)  # Raw JSON data that failed
    quarantined_at = Column(DateTime, default=utc_now, nullable=False)

    __table_args__ = (
        Index("idx_quarantine_batch_code", "batch_id", "error_code"),
    )


class CleanSalesRecord(Base):
    """
    Silver Layer: Cleaned, validated, typed, and deduplicated sales transactions.
    """
    __tablename__ = "clean_sales_records"

    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(64), index=True, nullable=False)
    transaction_id = Column(String(64), index=True, nullable=False)
    store_id = Column(String(32), index=True, nullable=False)
    product_id = Column(String(32), index=True, nullable=False)
    category = Column(String(64), nullable=False)
    sale_date = Column(DateTime, index=True, nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Float, nullable=False)
    discount_rate = Column(Float, default=0.0, nullable=False)
    total_amount = Column(Float, nullable=False)  # Derived: quantity * unit_price * (1 - discount_rate)
    is_promotion = Column(Boolean, default=False, nullable=False)
    cleaned_at = Column(DateTime, default=utc_now, nullable=False)

    __table_args__ = (
        Index("idx_clean_store_prod_date", "store_id", "product_id", "sale_date"),
        Index("idx_clean_transaction_id", "transaction_id"),
    )


class AIFeatureStore(Base):
    """
    Gold Layer: AI Feature Store.
    Aggregated and engineered time-series features ready for consumption by ML models.
    """
    __tablename__ = "ai_feature_store"

    id = Column(Integer, primary_key=True, autoincrement=True)
    store_id = Column(String(32), index=True, nullable=False)
    product_id = Column(String(32), index=True, nullable=False)
    feature_date = Column(DateTime, index=True, nullable=False)
    
    # Target / Aggregates
    sales_quantity = Column(Float, nullable=False)
    sales_revenue = Column(Float, nullable=False)
    
    # Lag Features
    lag_1_qty = Column(Float, nullable=True)
    lag_7_qty = Column(Float, nullable=True)
    lag_14_qty = Column(Float, nullable=True)
    
    # Rolling Statistics
    rolling_7_mean_qty = Column(Float, nullable=True)
    rolling_7_std_qty = Column(Float, nullable=True)
    rolling_14_mean_qty = Column(Float, nullable=True)
    rolling_30_mean_qty = Column(Float, nullable=True)
    
    # Calendar & Event Features
    day_of_week = Column(Integer, nullable=False)  # 0=Monday, 6=Sunday
    day_of_month = Column(Integer, nullable=False)
    month = Column(Integer, nullable=False)
    is_weekend = Column(Boolean, nullable=False)
    is_promotion_active = Column(Boolean, default=False, nullable=False)
    
    created_at = Column(DateTime, default=utc_now, nullable=False)

    __table_args__ = (
        Index("idx_features_store_prod_date", "store_id", "product_id", "feature_date", unique=True),
    )


class AIForecastPrediction(Base):
    """
    Output Model Predictions: Forecasted sales quantities and revenues for future dates.
    """
    __tablename__ = "ai_forecast_predictions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(64), index=True, nullable=False)
    model_version = Column(String(64), index=True, nullable=False)
    store_id = Column(String(32), index=True, nullable=False)
    product_id = Column(String(32), index=True, nullable=False)
    forecast_date = Column(DateTime, index=True, nullable=False)
    predicted_quantity = Column(Float, nullable=False)
    predicted_revenue = Column(Float, nullable=False)
    confidence_lower = Column(Float, nullable=False)
    confidence_upper = Column(Float, nullable=False)
    generated_at = Column(DateTime, default=utc_now, nullable=False)

    __table_args__ = (
        Index("idx_forecast_store_prod_date", "store_id", "product_id", "forecast_date"),
    )


class PipelineRun(Base):
    """
    Audit & Observability: Tracks execution metrics for each pipeline batch run.
    """
    __tablename__ = "pipeline_runs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(64), unique=True, index=True, nullable=False)
    pipeline_name = Column(String(128), default="nightly_sales_forecast_pipeline", nullable=False)
    status = Column(String(32), default="PENDING", nullable=False)  # PENDING, RUNNING, SUCCESS, FAILED
    current_stage = Column(String(64), default="INITIALIZED", nullable=False)
    
    total_raw_rows = Column(Integer, default=0, nullable=False)
    valid_rows = Column(Integer, default=0, nullable=False)
    quarantined_rows = Column(Integer, default=0, nullable=False)
    
    start_time = Column(DateTime, default=utc_now, nullable=False)
    end_time = Column(DateTime, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    
    error_message = Column(Text, nullable=True)
    metrics_summary = Column(JSON, nullable=True)  # Detailed dictionary with stage latencies and metrics


class ModelMetadata(Base):
    """
    AI Model Registry: Tracks trained model versions, performance evaluation metrics, and artifacts.
    """
    __tablename__ = "model_metadata"

    id = Column(Integer, primary_key=True, autoincrement=True)
    version = Column(String(64), unique=True, index=True, nullable=False)
    model_type = Column(String(64), default="RandomForest_TimeSeries", nullable=False)
    training_date = Column(DateTime, default=utc_now, nullable=False)
    train_samples = Column(Integer, nullable=False)
    eval_mae = Column(Float, nullable=False)
    eval_rmse = Column(Float, nullable=False)
    eval_r2 = Column(Float, nullable=False)
    eval_mape = Column(Float, nullable=True)
    artifact_path = Column(String(255), nullable=False)
    hyperparameters = Column(JSON, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
