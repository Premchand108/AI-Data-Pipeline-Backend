import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from config.settings import settings
from database.models import Base

logger = logging.getLogger(__name__)

def create_db_engine():
    db_url = settings.DATABASE_URL
    try:
        if db_url.startswith("sqlite"):
            engine = create_engine(
                db_url,
                connect_args={"check_same_thread": False},
                echo=False
            )
        else:
            # PostgreSQL connection pool configuration
            engine = create_engine(
                db_url,
                pool_pre_ping=True,
                pool_size=10,
                max_overflow=20,
                echo=False
            )
        # Test connection
        with engine.connect() as conn:
            pass
        return engine
    except Exception as e:
        logger.warning(
            f"Failed to connect to primary DB ({db_url}): {e}. "
            "Falling back to local SQLite database: sqlite:///./data_pipeline.db"
        )
        sqlite_fallback = "sqlite:///./data_pipeline.db"
        return create_engine(
            sqlite_fallback,
            connect_args={"check_same_thread": False},
            echo=False
        )

engine = create_db_engine()
SessionFactory = sessionmaker(autocommit=False, autoflush=False, bind=engine)
ScopedSession = scoped_session(SessionFactory)

def init_db():
    """Create all database tables if they do not exist."""
    Base.metadata.create_all(bind=engine)
    logger.info("Database initialized with all schema tables.")

def get_db():
    """Dependency generator for database sessions."""
    db = SessionFactory()
    try:
        yield db
    finally:
        db.close()
